class Comment
    attr_accessor :name_of_person , :feedback
    
    
    def initialize (name_of_person, feedback)
    @name_of_person = name_of_person
    @feedback = feedback
    end 

end 