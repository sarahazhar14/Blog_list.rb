class Category
    attr_accessor :niche, :description
    
    
    def initialize (niche, description = '')
    @niche = niche
    @description = description
    end 

end 

